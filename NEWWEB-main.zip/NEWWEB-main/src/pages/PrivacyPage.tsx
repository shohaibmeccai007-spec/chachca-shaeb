import React from 'react';
import { Shield, Lock, Eye, Database, Users, FileText } from 'lucide-react';

const PrivacyPage = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <Shield className="h-16 w-16 text-blue-600 mx-auto mb-6" />
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Privacy Policy
          </h1>
          <p className="text-xl text-gray-600">
            Your privacy and data security are our top priorities
          </p>
          <p className="text-sm text-gray-500 mt-4">
            Last updated: March 15, 2024
          </p>
        </div>

        {/* Quick Overview */}
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-8 mb-12">
          <h2 className="text-2xl font-bold text-blue-900 mb-4">Privacy at a Glance</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-start space-x-3">
              <Lock className="h-6 w-6 text-blue-600 mt-1" />
              <div>
                <h3 className="font-semibold text-blue-900">Encrypted & Secure</h3>
                <p className="text-blue-800 text-sm">All data encrypted in transit and at rest</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Eye className="h-6 w-6 text-blue-600 mt-1" />
              <div>
                <h3 className="font-semibold text-blue-900">Full Transparency</h3>
                <p className="text-blue-800 text-sm">Complete visibility into data usage</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Users className="h-6 w-6 text-blue-600 mt-1" />
              <div>
                <h3 className="font-semibold text-blue-900">Your Control</h3>
                <p className="text-blue-800 text-sm">You own and control your data</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-2xl shadow-lg p-8 space-y-12">
          <section>
            <div className="flex items-center space-x-3 mb-6">
              <Database className="h-6 w-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900">Information We Collect</h2>
            </div>
            <div className="space-y-6 text-gray-700">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Account Information</h3>
                <p className="leading-relaxed">
                  When you create an account or book a demo, we collect basic information such as your name, email address, company name, and phone number. This information is used to provide our services and communicate with you.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Marketing Data</h3>
                <p className="leading-relaxed">
                  To optimize your campaigns, we access and analyze marketing data from your connected platforms (Google Ads, Facebook Ads, Shopify, etc.). This includes campaign performance metrics, audience data, and conversion tracking information.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Usage Information</h3>
                <p className="leading-relaxed">
                  We collect information about how you use our platform, including features accessed, time spent, and interaction patterns. This helps us improve our service and provide better support.
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="flex items-center space-x-3 mb-6">
              <Lock className="h-6 w-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900">How We Protect Your Data</h2>
            </div>
            <div className="space-y-4 text-gray-700">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-2">🔒 Encryption</h3>
                <p>All data is encrypted using industry-standard AES-256 encryption both in transit and at rest.</p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-2">🏢 SOC 2 Compliance</h3>
                <p>We maintain SOC 2 Type II certification with regular third-party security audits.</p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-2">🌍 GDPR Compliant</h3>
                <p>Full compliance with European data protection regulations and privacy standards.</p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-2">🔐 Access Controls</h3>
                <p>Strict access controls with multi-factor authentication and role-based permissions.</p>
              </div>
            </div>
          </section>

          <section>
            <div className="flex items-center space-x-3 mb-6">
              <FileText className="h-6 w-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900">How We Use Your Information</h2>
            </div>
            <div className="space-y-4 text-gray-700">
              <ul className="space-y-3">
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <span>Provide and improve our AI marketing optimization services</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <span>Analyze campaign performance and generate insights</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <span>Communicate with you about your account and our services</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <span>Comply with legal obligations and protect against fraud</span>
                </li>
              </ul>
            </div>
          </section>

          <section>
            <div className="flex items-center space-x-3 mb-6">
              <Users className="h-6 w-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900">Your Rights and Controls</h2>
            </div>
            <div className="space-y-4 text-gray-700">
              <p className="leading-relaxed">You have complete control over your data. You can:</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-blue-50 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-900 mb-2">Access Your Data</h3>
                  <p className="text-blue-800">Request a copy of all data we have about you</p>
                </div>
                
                <div className="bg-blue-50 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-900 mb-2">Update Information</h3>
                  <p className="text-blue-800">Modify or correct your personal information</p>
                </div>
                
                <div className="bg-blue-50 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-900 mb-2">Delete Your Data</h3>
                  <p className="text-blue-800">Request deletion of your personal data</p>
                </div>
                
                <div className="bg-blue-50 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-900 mb-2">Data Portability</h3>
                  <p className="text-blue-800">Export your data in a machine-readable format</p>
                </div>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Data Sharing</h2>
            <div className="bg-red-50 border border-red-200 rounded-lg p-6">
              <p className="text-red-800 font-semibold mb-2">We never sell your data.</p>
              <p className="text-red-700">
                Your marketing data and personal information are never shared with third parties for advertising or commercial purposes. We only share data when required by law or with your explicit consent.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Contact Us</h2>
            <div className="bg-gray-50 rounded-lg p-6">
              <p className="text-gray-700 mb-4">
                If you have questions about this Privacy Policy or need to exercise your data rights, contact our Privacy Team:
              </p>
              
              <div className="space-y-2 text-gray-700">
                <p><strong>Email:</strong> privacy@flable.ai</p>
                <p><strong>Address:</strong> Flable.ai Privacy Team, San Francisco, CA</p>
                <p><strong>Response Time:</strong> We respond to all privacy requests within 72 hours</p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPage;
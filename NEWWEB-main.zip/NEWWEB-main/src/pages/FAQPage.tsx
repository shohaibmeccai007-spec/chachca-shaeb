import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQPage = () => {
  const [expandedFAQ, setExpandedFAQ] = useState(null);

  const faqs = [
    {
      category: 'Getting Started',
      questions: [
        {
          q: 'How does Flable.ai work?',
          a: 'Flable.ai uses advanced AI agents that connect to your existing marketing accounts (Google Ads, Facebook, Shopify, etc.) and automatically optimize your campaigns 24/7. Our AI CMO orchestrates all agents to work together for maximum impact.'
        },
        {
          q: 'What marketing channels do you support?',
          a: 'We support all major marketing channels including Google Ads, Facebook Ads, Instagram, LinkedIn, TikTok, YouTube, email marketing, and e-commerce platforms like Shopify, WooCommerce, and Magento.'
        },
        {
          q: 'How long does onboarding take?',
          a: 'Typical onboarding takes 1-2 weeks depending on the complexity of your setup. We handle all the technical integration while you continue running your current campaigns.'
        }
      ]
    },
    {
      category: 'Privacy & Security',
      questions: [
        {
          q: 'How do you handle my data?',
          a: 'Your data is encrypted both in transit and at rest. We never share your data with third parties and you maintain full ownership. We\'re GDPR compliant and SOC 2 certified.'
        },
        {
          q: 'Can I maintain oversight of my campaigns?',
          a: 'Absolutely. You have full visibility into all AI decisions through our dashboard. You can set guardrails, approve changes, and override any optimization at any time.'
        },
        {
          q: 'What happens to my data if I cancel?',
          a: 'We provide a complete data export and securely delete all your information from our systems within 30 days of cancellation, as required by privacy regulations.'
        }
      ]
    },
    {
      category: 'Performance & Results',
      questions: [
        {
          q: 'What kind of results can I expect?',
          a: 'While results vary by industry and starting point, our clients typically see 35%+ improvement in conversions, 250%+ ROAS improvement, and 60% reduction in ad waste within the first 30 days.'
        },
        {
          q: 'How do you measure success?',
          a: 'We track key metrics like ROAS, CPA, conversion rate, and overall revenue growth. Our dashboard provides real-time insights into performance improvements across all channels.'
        },
        {
          q: 'What if the AI makes a mistake?',
          a: 'Our AI agents have multiple safety checks and learn from any suboptimal decisions. You can also set spending limits and approval workflows for major changes. We also provide 24/7 monitoring.'
        }
      ]
    },
    {
      category: 'Integrations',
      questions: [
        {
          q: 'What tools do you integrate with?',
          a: 'We integrate with 50+ marketing and e-commerce platforms including Google Analytics, Facebook Ads Manager, Shopify, HubSpot, Salesforce, and many more.'
        },
        {
          q: 'Do I need to change my current setup?',
          a: 'No, Flable.ai works with your existing tools and workflows. We simply add an AI optimization layer on top of your current marketing stack.'
        },
        {
          q: 'Can you integrate with custom tools?',
          a: 'Yes, our Enterprise plan includes custom API integrations. We can connect to any tool with an API or webhook capability.'
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Frequently Asked Questions
          </h1>
          <p className="text-xl text-gray-600">
            Everything you need to know about Flable.ai
          </p>
        </div>

        <div className="space-y-8">
          {faqs.map((category, categoryIndex) => (
            <div key={categoryIndex} className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="bg-blue-50 px-6 py-4 border-b">
                <h2 className="text-xl font-bold text-blue-900">{category.category}</h2>
              </div>
              
              <div className="divide-y divide-gray-200">
                {category.questions.map((faq, faqIndex) => {
                  const faqId = `${categoryIndex}-${faqIndex}`;
                  const isExpanded = expandedFAQ === faqId;
                  
                  return (
                    <div key={faqIndex}>
                      <button
                        className="w-full px-6 py-4 text-left hover:bg-gray-50 transition-colors focus:outline-none focus:bg-gray-50"
                        onClick={() => setExpandedFAQ(isExpanded ? null : faqId)}
                      >
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-semibold text-gray-900 pr-4">
                            {faq.q}
                          </h3>
                          {isExpanded ? (
                            <ChevronUp className="h-5 w-5 text-gray-500 flex-shrink-0" />
                          ) : (
                            <ChevronDown className="h-5 w-5 text-gray-500 flex-shrink-0" />
                          )}
                        </div>
                      </button>
                      
                      {isExpanded && (
                        <div className="px-6 pb-4">
                          <p className="text-gray-600 leading-relaxed">
                            {faq.a}
                          </p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Contact CTA */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-indigo-700 rounded-xl p-8 text-center text-white">
          <h2 className="text-2xl font-bold mb-4">Still Have Questions?</h2>
          <p className="text-lg mb-6 text-blue-100">
            Our team is here to help you understand how Flable.ai can transform your marketing
          </p>
          <button className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
            Contact Support
          </button>
        </div>
      </div>
    </div>
  );
};

export default FAQPage;
import React from 'react';
import { FileText, Scale, Shield, AlertCircle } from 'lucide-react';

const TermsPage = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <Scale className="h-16 w-16 text-blue-600 mx-auto mb-6" />
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Terms of Service
          </h1>
          <p className="text-xl text-gray-600">
            Our commitment to transparent and fair service
          </p>
          <p className="text-sm text-gray-500 mt-4">
            Last updated: March 15, 2024
          </p>
        </div>

        {/* Important Notice */}
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-8 mb-12">
          <div className="flex items-start space-x-4">
            <AlertCircle className="h-6 w-6 text-blue-600 mt-1" />
            <div>
              <h2 className="text-xl font-bold text-blue-900 mb-3">Important Information</h2>
              <p className="text-blue-800 leading-relaxed">
                These Terms of Service govern your use of Flable.ai's AI-powered marketing platform. 
                By using our services, you agree to these terms. We recommend reading this document carefully.
              </p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-2xl shadow-lg p-8 space-y-12">
          <section>
            <div className="flex items-center space-x-3 mb-6">
              <FileText className="h-6 w-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900">1. Service Description</h2>
            </div>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                Flable.ai provides AI-powered digital marketing optimization services ("Services") that include:
              </p>
              <ul className="space-y-2 ml-6">
                <li className="flex items-start space-x-2">
                  <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2"></div>
                  <span>Automated campaign optimization across multiple advertising platforms</span>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2"></div>
                  <span>AI-driven creative generation and testing</span>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2"></div>
                  <span>Real-time analytics and performance reporting</span>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2"></div>
                  <span>Cross-channel marketing intelligence and insights</span>
                </li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">2. Account Registration and Access</h2>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                To use our Services, you must create an account by providing accurate and complete information. 
                You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.
              </p>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-2">Account Requirements:</h3>
                <ul className="space-y-1 text-sm">
                  <li>• You must be at least 18 years old</li>
                  <li>• You must represent a legitimate business entity</li>
                  <li>• You must provide accurate contact and billing information</li>
                  <li>• You must comply with all applicable laws and regulations</li>
                </ul>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">3. Service Usage and Limitations</h2>
            <div className="space-y-6 text-gray-700">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Acceptable Use</h3>
                <p className="leading-relaxed mb-4">You may use our Services only for lawful business purposes. Prohibited activities include:</p>
                <ul className="space-y-2">
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2"></div>
                    <span>Promoting illegal products, services, or activities</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2"></div>
                    <span>Attempting to reverse engineer or duplicate our AI technology</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2"></div>
                    <span>Using the Services to spam or send unsolicited communications</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2"></div>
                    <span>Interfering with or disrupting our Services or servers</span>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Service Availability</h3>
                <p className="leading-relaxed">
                  We strive to maintain 99.9% uptime but do not guarantee uninterrupted service. We may temporarily suspend access for maintenance, updates, or security purposes with advance notice when possible.
                </p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">4. Payment and Billing</h2>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                Our Services are provided on a subscription basis with custom pricing based on your needs. 
                Payment terms will be specified in your service agreement.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-green-50 rounded-lg p-4">
                  <h3 className="font-semibold text-green-900 mb-2">✓ 30-Day Trial</h3>
                  <p className="text-green-800 text-sm">Try our Services risk-free for 30 days</p>
                </div>
                
                <div className="bg-blue-50 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-900 mb-2">📄 Flexible Terms</h3>
                  <p className="text-blue-800 text-sm">Monthly or annual billing options available</p>
                </div>
                
                <div className="bg-orange-50 rounded-lg p-4">
                  <h3 className="font-semibold text-orange-900 mb-2">🔄 Easy Cancellation</h3>
                  <p className="text-orange-800 text-sm">Cancel anytime with 30-day notice</p>
                </div>
                
                <div className="bg-purple-50 rounded-lg p-4">
                  <h3 className="font-semibold text-purple-900 mb-2">💳 Secure Billing</h3>
                  <p className="text-purple-800 text-sm">PCI-compliant payment processing</p>
                </div>
              </div>
            </div>
          </section>

          <section>
            <div className="flex items-center space-x-3 mb-6">
              <Shield className="h-6 w-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900">5. Data Ownership and Privacy</h2>
            </div>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <p className="text-blue-900 font-semibold mb-2">Your Data Remains Yours</p>
                <p className="text-blue-800">
                  You retain ownership of all marketing data, customer information, and content you provide to our Services. 
                  We never claim ownership of your data or use it for purposes other than providing our Services to you.
                </p>
              </div>
              
              <p>
                Our data handling practices are governed by our Privacy Policy, which forms part of these Terms. 
                We implement industry-standard security measures to protect your data and comply with applicable privacy regulations including GDPR and CCPA.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">6. Intellectual Property</h2>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                The Flable.ai platform, including our AI algorithms, software, and related technology, is protected by intellectual property rights. 
                You receive a limited, non-exclusive license to use our Services during your subscription term.
              </p>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-2">What You Can Do:</h3>
                <ul className="space-y-1 text-sm">
                  <li>• Use our Services for your business marketing needs</li>
                  <li>• Access and export your data at any time</li>
                  <li>• Integrate our Services with your existing tools</li>
                </ul>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4 mt-4">
                <h3 className="font-semibold text-gray-900 mb-2">What You Cannot Do:</h3>
                <ul className="space-y-1 text-sm">
                  <li>• Copy, modify, or reverse engineer our technology</li>
                  <li>• Use our Services to create competing products</li>
                  <li>• Share your account access with unauthorized parties</li>
                </ul>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">7. Limitation of Liability</h2>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                While we strive to provide excellent service, marketing results can vary based on many factors outside our control. 
                Our liability is limited to the amount you paid for our Services in the 12 months preceding any claim.
              </p>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-yellow-800 text-sm">
                  <strong>Important:</strong> We provide our Services "as is" and cannot guarantee specific marketing results or ROI improvements. 
                  Past performance does not guarantee future results.
                </p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">8. Termination</h2>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                Either party may terminate this agreement with 30 days' written notice. Upon termination, you will retain access to your data and have 90 days to export it from our platform.
              </p>
              
              <p>
                We may immediately terminate your account if you violate these Terms or engage in activities that could harm our Services or other users.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">9. Contact Information</h2>
            <div className="bg-gray-50 rounded-lg p-6">
              <p className="text-gray-700 mb-4">
                If you have questions about these Terms of Service, please contact our legal team:
              </p>
              
              <div className="space-y-2 text-gray-700">
                <p><strong>Email:</strong> legal@flable.ai</p>
                <p><strong>Address:</strong> Flable.ai Legal Department, San Francisco, CA</p>
                <p><strong>Phone:</strong> +1 (555) 123-4567</p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default TermsPage;
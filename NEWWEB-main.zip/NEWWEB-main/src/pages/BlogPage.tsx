import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, User, ArrowRight, TrendingUp, Brain, Target, Zap } from 'lucide-react';

const BlogPage = () => {
  const featuredPost = {
    title: "The Future of AI Marketing: 5 Trends That Will Transform Your Strategy in 2024",
    excerpt: "Discover how AI is revolutionizing digital marketing and what it means for your campaigns. From predictive analytics to automated creative generation, these trends will define the next era of marketing success.",
    author: "Sarah Chen",
    date: "March 15, 2024",
    readTime: "8 min read",
    image: "https://images.pexels.com/photos/373543/pexels-photo-373543.jpeg?auto=compress&cs=tinysrgb&w=800",
    category: "AI Marketing",
    slug: "future-ai-marketing-trends-2024"
  };

  const blogPosts = [
    {
      title: "Case Study: How TechFlow Increased Conversions by 247% Using AI Agents",
      excerpt: "Learn how TechFlow Solutions transformed their digital marketing with Flable.ai's AI agents, achieving remarkable ROI improvements in just 60 days.",
      author: "Mike Rodriguez",
      date: "March 12, 2024",
      readTime: "6 min read",
      image: "https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "Case Studies",
      slug: "techflow-conversion-case-study"
    },
    {
      title: "AI vs. Human Marketing Teams: The Complete Comparison Guide",
      excerpt: "Explore the benefits and limitations of AI marketing automation versus traditional human-led campaigns. Discover the optimal hybrid approach.",
      author: "Jennifer Liu",
      date: "March 10, 2024",
      readTime: "10 min read",
      image: "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "Strategy",
      slug: "ai-vs-human-marketing-comparison"
    },
    {
      title: "Reducing Ad Waste: 7 AI-Powered Strategies That Actually Work",
      excerpt: "Stop throwing money at underperforming campaigns. These AI-driven optimization techniques can cut your ad waste by up to 60% while boosting performance.",
      author: "David Park",
      date: "March 8, 2024",
      readTime: "7 min read",
      image: "https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "Optimization",
      slug: "reducing-ad-waste-ai-strategies"
    },
    {
      title: "The Ultimate Guide to Marketing Automation ROI in 2024",
      excerpt: "Discover how to measure, optimize, and maximize your marketing automation ROI. Includes benchmarks, KPIs, and real-world examples.",
      author: "Lisa Thompson",
      date: "March 5, 2024",
      readTime: "12 min read",
      image: "https://images.pexels.com/photos/590020/pexels-photo-590020.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "Analytics",
      slug: "marketing-automation-roi-guide-2024"
    },
    {
      title: "Cross-Channel Attribution: How AI Solves Marketing's Biggest Challenge",
      excerpt: "Traditional attribution models are broken. Learn how AI-powered attribution provides accurate insights across all your marketing channels.",
      author: "Robert Kim",
      date: "March 1, 2024",
      readTime: "9 min read",
      image: "https://images.pexels.com/photos/590016/pexels-photo-590016.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "Analytics",
      slug: "ai-cross-channel-attribution-guide"
    },
    {
      title: "Creative AI: How Machines Are Revolutionizing Ad Content Generation",
      excerpt: "From copywriting to visual design, AI is transforming how marketing content is created. Explore the latest tools and techniques.",
      author: "Emily Watson",
      date: "February 28, 2024",
      readTime: "8 min read",
      image: "https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=400",
      category: "Creative",
      slug: "creative-ai-content-generation-revolution"
    }
  ];

  const categories = [
    { name: "All", count: blogPosts.length + 1, icon: Brain },
    { name: "AI Marketing", count: 3, icon: Brain },
    { name: "Case Studies", count: 2, icon: TrendingUp },
    { name: "Strategy", count: 1, icon: Target },
    { name: "Analytics", count: 2, icon: Zap }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-700 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Marketing Intelligence Hub
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Insights, strategies, and case studies to help you master AI-powered marketing
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Categories */}
        <div className="flex flex-wrap gap-4 mb-12 justify-center">
          {categories.map((category, index) => (
            <button
              key={index}
              className={`flex items-center space-x-2 px-6 py-3 rounded-full transition-all duration-200 ${
                index === 0 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-white text-gray-700 hover:bg-blue-50 hover:text-blue-600'
              } shadow-sm hover:shadow-md`}
            >
              <category.icon className="h-4 w-4" />
              <span className="font-medium">{category.name}</span>
              <span className={`px-2 py-1 rounded-full text-xs ${
                index === 0 ? 'bg-blue-500' : 'bg-gray-200'
              }`}>
                {category.count}
              </span>
            </button>
          ))}
        </div>

        {/* Featured Post */}
        <div className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
            <div className="md:flex">
              <div className="md:w-1/2">
                <img
                  src={featuredPost.image}
                  alt={featuredPost.title}
                  className="w-full h-64 md:h-full object-cover"
                />
              </div>
              <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
                <div className="flex items-center space-x-4 mb-4">
                  <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                    Featured
                  </span>
                  <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm">
                    {featuredPost.category}
                  </span>
                </div>
                
                <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4 leading-tight">
                  {featuredPost.title}
                </h2>
                
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {featuredPost.excerpt}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <User className="h-4 w-4" />
                      <span>{featuredPost.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>{featuredPost.date}</span>
                    </div>
                    <span>{featuredPost.readTime}</span>
                  </div>
                  
                  <Link
                    to={`/blog/${featuredPost.slug}`}
                    className="inline-flex items-center space-x-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors"
                  >
                    <span>Read More</span>
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <article
              key={index}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              <img
                src={post.image}
                alt={post.title}
                className="w-full h-48 object-cover"
              />
              
              <div className="p-6">
                <div className="flex items-center space-x-2 mb-3">
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium">
                    {post.category}
                  </span>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
                  {post.title}
                </h3>
                
                <p className="text-gray-600 mb-4 line-clamp-3">
                  {post.excerpt}
                </p>
                
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4" />
                    <span>{post.author}</span>
                  </div>
                  <span>{post.readTime}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">{post.date}</span>
                  <Link
                    to={`/blog/${post.slug}`}
                    className="inline-flex items-center space-x-1 text-blue-600 font-semibold hover:text-blue-700 transition-colors"
                  >
                    <span>Read</span>
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* Newsletter Signup */}
        <div className="mt-20">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-8 md:p-12 text-center text-white">
            <h3 className="text-3xl font-bold mb-4">Stay Ahead of the Curve</h3>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Get the latest AI marketing insights, case studies, and strategies delivered to your inbox weekly.
            </p>
            
            <div className="max-w-md mx-auto flex gap-4">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-300"
              />
              <button className="bg-blue-800 hover:bg-blue-900 px-6 py-3 rounded-lg font-semibold transition-colors">
                Subscribe
              </button>
            </div>
            
            <p className="text-sm text-blue-200 mt-4">
              Join 10,000+ marketers. Unsubscribe anytime.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogPage;